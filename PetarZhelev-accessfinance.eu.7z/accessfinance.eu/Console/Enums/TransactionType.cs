namespace TransactionSystem.Models;

public enum TransactionType
{
    Deposit,
    Withdrawal
}